package com.example.shamo

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
